package com.cg.PaymentWallet_JDBC;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.sql.SQLException;

import org.junit.Test;

import com.cg.paymentwallet.bean.Customer;
import com.cg.paymentwallet.bean.Wallet;
import com.cg.paymentwallet.exception.WalletException;
import com.cg.paymentwallet.service.IWalletService;
import com.cg.paymentwallet.service.WalletServiceImpl;

public class AppTest {
	public static IWalletService iWalletService=new WalletServiceImpl();
    @Test
	public void addCustomerTestTrue() throws WalletException
	{
		Customer customer1 = new Customer("9176042782","krish","Krish@123","krish@gmail.com",new Wallet());
		assertEquals("9176042782",iWalletService.addCustomer(customer1));
			
	}
    @Test
  	public void addCustomerTestFalse() throws WalletException
  	{

  		Customer customer2 = new Customer("9505742799","Briseis","Briseis@123","briseis@gmail.com",new Wallet());
  		assertNotEquals("56968621",iWalletService.addCustomer(customer2));
  		
  	}
	

	@Test
	public void initBalanceTest() throws WalletException
	{
		Customer customer3 = new Customer("9949453482","krish","Krish@123","krish@gmail.com",new Wallet());
		iWalletService.addCustomer(customer3);
		assertEquals(BigDecimal.valueOf(0.0),customer3.getWallet().getBalance());
		
	}
	
	@Test
	public void depositMoneyTest() throws WalletException, ClassNotFoundException, SQLException
	{
		Customer customer4 = new Customer("9176042783","Krish","Krishna@123","sai@gmail.com",new Wallet());
		iWalletService.addCustomer(customer4);
		iWalletService.deposit(customer4, BigDecimal.valueOf(8500.00));
		Customer result = iWalletService.showBalance("9176042783", "Krishna@123");
		assertEquals(BigDecimal.valueOf(8500.00),result.getWallet().getBalance());
	}
	@Test
	public void withdrawMoneyTestTrue() throws WalletException, ClassNotFoundException, SQLException
	{
		Customer customer5 = new Customer("9176042781","Krish","Krishna@123","sai@gmail.com",new Wallet());
		iWalletService.addCustomer(customer5);
		iWalletService.deposit(customer5, BigDecimal.valueOf(8500.00));
		assertTrue(iWalletService.withDraw(customer5, BigDecimal.valueOf(3000.00)));
	}

	
	@Test(expected = WalletException.class)
	public void withdrawMoneyTestFalse() throws WalletException, ClassNotFoundException, SQLException
	{
		Customer customer6 = new Customer("9176042784","charish","Charish@123","cherry@gmail.com",new Wallet());
		iWalletService.addCustomer(customer6);
		iWalletService.deposit(customer6, BigDecimal.valueOf(8500.00));
		assertFalse(iWalletService.withDraw(customer6, BigDecimal.valueOf(9000.00)));
	}

}
